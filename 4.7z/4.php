<!DOCTYPE html>
<html>
<head>
<tittle>Cargo Sales Management</tittle>
	<link rel="stylesheet" href="4.css" type="text/css">
</head>
<body>


	<h2>Basic Price(Based on Distance/Location)</h2>
     

<form class="box">
<table id="customer">
  <tr id="2">
    <th id="3">Source</th>
	  <th id="3">Destination</th>
	   <th id="3"> Price</th>
     </tr>
	
  <tr id="2">
    <td id="2">Delhi</td>
    <td id="2">Mumbai</td>
    <td id="2">1500</td>
  </tr>
  <tr id="2">
    <td id="2">Bangalore</td>
    <td id="2">Kolkata</td>
    <td id="2">2500</td>
  </tr>
  <tr id="2">
    <td id="2">Hyderabad</td>
    <td id="2">Chennai</td>
    <td id="2">1000</td>
  </tr>
  <tr id="2">
    <td id="2">Delhi</td>
    <td id="2">Kolkata</td>
    <td id="2">1500</td>
  </tr>
</table>
	</form>
	<br>
	<br>
	<form class="table">
	<table class="customer1">	
  <tr>
    <th>Volume</th> 
	   <th> Price</th>
     </tr>
	
  <tr>
    <td>Delhi</td>
    <td>Mumbai</td>
  
  </tr>
  <tr>
    <td>Bangalore</td>
    <td>Kolkata</td>
 
  </tr>
  <tr>
    <td>Hyderabad</td>
    <td>Chennai</td>
  </tr>
  <tr>
    <td>Delhi</td>
	  <td>Kolkata</td>
  </tr>
  
</table>
	</form>

</body>
</html>
